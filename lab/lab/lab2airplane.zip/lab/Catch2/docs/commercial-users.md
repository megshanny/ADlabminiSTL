<a id="top"></a>
# Commercial users of Catch2

Catch2 is also widely used in proprietary code bases. This page contains
some of them that are willing to share this information.

If you want to add your organisation, please check that there is no issue
with you sharing this fact.

 - Bloomberg
 - [Bloomlife](https://bloomlife.com)
 - [Inscopix Inc.](https://www.inscopix.com/)
 - Locksley.CZ
 - [Makimo](https://makimo.pl/)
 - NASA
 - [Nexus Software Systems](https://nexwebsites.com)
 - [UX3D](https://ux3d.io)
 - [King](https://king.com)


---

[Home](Readme.md#top)
